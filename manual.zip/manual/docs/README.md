# 개요

> 기상정보를 완벽하게 지원하는 최고의 체계! 기상정보지원체계입니다. 

!> **제대로된분석**은 필수입니다! 모두 기상정보지원체계를 영접합시다. 

## 코드최적화기법

## 해야할일들
### 1.1 해야할일들1
- [x] baz
- [x] baz
- [x] baz
- [x] baz

```js
var express = require('express');
var app = express();
app.use(express.static("docs"))
app.listen(3000);
```

```css 
```
![logo](./img/icon.svg ':size=100')
